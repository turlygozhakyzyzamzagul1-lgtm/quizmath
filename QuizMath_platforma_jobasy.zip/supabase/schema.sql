-- Supabase SQL Editor ішінде орындаңыз.
create table if not exists public.games (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  grade text,
  kind text not null,
  content jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
alter table public.games enable row level security;
create policy "Users can read own games" on public.games
 for select to authenticated using (auth.uid() = user_id);
create policy "Users can insert own games" on public.games
 for insert to authenticated with check (auth.uid() = user_id);
create policy "Users can update own games" on public.games
 for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users can delete own games" on public.games
 for delete to authenticated using (auth.uid() = user_id);
